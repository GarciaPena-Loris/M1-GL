package m1.archi.grpcagence;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrpcAgenceApplicationTests {

    @Test
    void contextLoads() {
    }

}
