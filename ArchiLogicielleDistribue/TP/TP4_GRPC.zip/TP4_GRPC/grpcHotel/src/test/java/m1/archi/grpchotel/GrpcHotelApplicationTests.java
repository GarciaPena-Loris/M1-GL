package m1.archi.grpchotel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GrpcHotelApplicationTests {

	@Test
	void contextLoads() {
	}

}
