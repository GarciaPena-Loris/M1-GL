package m1.archi.grpchotel.repositories;

import m1.archi.grpchotel.models.Adresse;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdresseRepository extends JpaRepository<Adresse, Long> {
}
