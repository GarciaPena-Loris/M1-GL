package m1.archi.grpcclient.exceptions;

public class InterfaceException extends RuntimeException {

    public InterfaceException(String message) {
        super(message);
    }
}
