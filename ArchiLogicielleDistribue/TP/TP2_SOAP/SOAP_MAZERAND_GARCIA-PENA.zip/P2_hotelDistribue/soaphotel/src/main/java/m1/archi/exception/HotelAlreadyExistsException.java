package m1.archi.exception;

public class HotelAlreadyExistsException extends Exception {
    public HotelAlreadyExistsException(String message) {
        super(message);
    }
}
