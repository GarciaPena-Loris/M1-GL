package m1.archi.exception;

public class HotelNotFoundException extends Exception {
     public HotelNotFoundException(String message) {
        super(message);
    }
}
