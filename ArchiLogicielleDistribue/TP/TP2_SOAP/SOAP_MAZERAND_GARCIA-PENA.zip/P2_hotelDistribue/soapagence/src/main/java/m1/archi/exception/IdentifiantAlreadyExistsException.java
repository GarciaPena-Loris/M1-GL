package m1.archi.exception;

public class IdentifiantAlreadyExistsException extends Exception {
    public IdentifiantAlreadyExistsException(String message) {
        super(message);
    }
}
