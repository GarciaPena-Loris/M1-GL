@javax.xml.bind.annotation.XmlSchema(namespace = "http://service.archi.m1/")
package m1.archi.agence;
