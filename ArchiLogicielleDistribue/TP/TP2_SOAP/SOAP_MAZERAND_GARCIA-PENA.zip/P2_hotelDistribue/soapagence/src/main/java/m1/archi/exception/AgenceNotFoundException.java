package m1.archi.exception;

public class AgenceNotFoundException extends Exception {
    public AgenceNotFoundException(String message) {
        super(message);
    }
}
