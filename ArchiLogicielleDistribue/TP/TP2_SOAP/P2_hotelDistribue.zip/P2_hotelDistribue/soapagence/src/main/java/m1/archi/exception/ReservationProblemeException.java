package m1.archi.exception;

public class ReservationProblemeException extends Exception {
    public ReservationProblemeException(String message) {
        super(message);
    }
}
