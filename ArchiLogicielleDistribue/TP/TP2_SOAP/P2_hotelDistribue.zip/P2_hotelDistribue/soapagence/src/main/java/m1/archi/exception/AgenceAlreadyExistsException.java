package m1.archi.exception;

public class AgenceAlreadyExistsException extends Exception {
    public AgenceAlreadyExistsException(String message) {
        super(message);
    }
}
