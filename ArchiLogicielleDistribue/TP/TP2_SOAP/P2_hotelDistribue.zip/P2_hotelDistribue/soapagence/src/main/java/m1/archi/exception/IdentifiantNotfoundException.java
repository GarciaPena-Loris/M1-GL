package m1.archi.exception;

public class IdentifiantNotfoundException extends Exception {
    public IdentifiantNotfoundException(String message) {
        super(message);
    }
}
