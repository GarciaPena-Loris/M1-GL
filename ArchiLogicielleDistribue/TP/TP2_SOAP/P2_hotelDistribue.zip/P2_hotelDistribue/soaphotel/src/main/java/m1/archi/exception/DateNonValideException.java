package m1.archi.exception;

public class DateNonValideException extends Exception {
    public DateNonValideException(String message) {
        super(message);
    }
}
