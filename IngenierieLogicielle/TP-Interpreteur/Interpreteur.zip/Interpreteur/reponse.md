# TP 11 : Schéma interpréteur

## Question 1
Oui.

## Question 2
Non. Il faudrait modifier le type `form`. Faire une extension de ce type (par exemple `form_with_xor`) ne fonctionnerait pas car les opérations définies dans `form` ne pourraient pas utiliser le _Xor_.

## Question 3
✅

## Question 4
✅

## Question 5
Oui c'est possible en objet, il suffit d'étendre la classe avec le patron de conception interpréteur (ajout de symboles non terminaux ou terminaux).

## Question 6
Oui, en supposant que le code est extensible (accesseurs).
