package org.example.formula.terminal;

import org.example.formula.Formula;

public abstract class TerminalFormula extends Formula {
}
