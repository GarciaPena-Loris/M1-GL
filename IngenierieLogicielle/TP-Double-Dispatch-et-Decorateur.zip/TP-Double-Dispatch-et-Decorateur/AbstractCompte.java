public abstract class AbstractCompte {

    public abstract double prixLocation(Produit produit);
    
}
